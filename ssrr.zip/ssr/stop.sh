#!/system/bin/sh

status_list=(
redsocks
pdnsd
gost
ss-local
);

for i in ${status_list[@]}
do
  kill $(pgrep $i)
done

ip route del local 0/0 dev lo table 123
ip rule del fwmark 0x2333 table 123
#
iptables -t mangle -D PREROUTING -j redsocks_pre
iptables -t mangle -D OUTPUT -j redsocks_out
iptables -t nat -D PREROUTING -j nat_pre
iptables -t nat -D OUTPUT -j nat_out
#
iptables -t mangle -F redsocks_pre
iptables -t mangle -F mangle_lan
iptables -t mangle -F redsocks_out
iptables -t mangle -X redsocks_pre
iptables -t mangle -X mangle_lan
iptables -t mangle -X redsocks_out
#
iptables -t nat -F nat_pre
iptables -t nat -F nat_lan
iptables -t nat -F nat_out
iptables -t nat -F shadowsocks
iptables -t nat -X nat_pre
iptables -t nat -X nat_lan
iptables -t nat -X nat_out
iptables -t nat -X shadowsocks