#!/usr/bin/env bash
PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH

status_list=(
redsocks
koolproxy
ss-local
);

for i in ${status_list[@]}
do
  kill $(pgrep $i)
done


iptables -t nat -D OUTPUT -j nat_out

iptables -t nat -F nat_lan
iptables -t nat -F nat_out
iptables -t nat -F koolproxy
iptables -t nat -F shadowsocks
iptables -t nat -X nat_lan
iptables -t nat -X nat_out
iptables -t nat -X koolproxy
iptables -t nat -X shadowsocks