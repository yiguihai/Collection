#!/usr/bin/env bash
PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH

now_path="${0%/*}";

get_ip()(
    local IP=$( ip addr | egrep -o '[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}' | egrep -v "^192\.168|^172\.1[6-9]\.|^172\.2[0-9]\.|^172\.3[0-2]\.|^10\.|^127\.|^255\.|^0\." | head -n 1 )
    [ -z ${IP} ] && IP=$( wget -qO- -t1 -T2 ipv4.icanhazip.com )
    [ -z ${IP} ] && IP=$( wget -qO- -t1 -T2 ipinfo.io/ip )
    echo ${IP}
);

lan_list=(
0.0.0.0/8
10.0.0.0/8
100.64.0.0/10
127.0.0.0/8
169.254.0.0/16
172.16.0.0/12
192.0.0.0/29
192.0.2.0/24
192.88.99.0/24
192.168.0.0/16
198.18.0.0/15
198.51.100.0/24
203.0.113.0/24
224.0.0.0/3
#$(get_ip)
);

ss_nat()
(
iptables -t nat -N nat_lan
iptables -t nat -N nat_out
iptables -t nat -N koolproxy
iptables -t nat -N shadowsocks
for i in ${lan_list[@]}
do
  iptables -t nat -A nat_lan -d $i -j ACCEPT
done
iptables -t nat -A nat_out -j nat_lan
iptables -t nat -A nat_out -m owner --uid-owner $(grep 'nobody' /etc/passwd|cut -f 3 -d ':') -j ACCEPT
iptables -t nat -A nat_out -m owner ! --uid-owner $(id -u) -j koolproxy
iptables -t nat -A nat_out -j shadowsocks
iptables -t nat -A OUTPUT -j nat_out
iptables -t nat -A koolproxy -p tcp -m multiport --dports 80,8080 -j REDIRECT --to-ports 3000
iptables -t nat -A shadowsocks -p tcp -j REDIRECT --to-ports 1024
#iptables -t nat -A shadowsocks -p udp --dport 53 -j REDIRECT --to-ports 1053
#iptables -t mangle -A mangle_lan -p udp -j LOG --log-prefix "{NL}" --log-uid
#grep '{NL}' /proc/kmsg &
);


if [ ! -d $now_path ]; then
  now_path=$(pwd); 
fi


if [ $(cat /proc/sys/net/ipv4/ip_forward) -le 0 ]; then
  sysctl -w net.ipv4.ip_forward=1 1> /dev/null;
fi

if [ ! -d $now_path/data ]; then
  $now_path/koolproxy --cert
fi

$now_path/redsocks -c $now_path/redsocks.conf
$now_path/ss-local --acl $now_path/gfwlist.acl -f $now_path/ss-deamon.pid -c $now_path/ss-local.conf
$now_path/koolproxy -l 0 -d
ss_nat
