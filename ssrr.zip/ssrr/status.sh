#!/usr/bin/env bash
PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH

status_list=(
redsocks
ss-local
);
for i in ${status_list[@]}
do
  echo "$i $(pgrep $i)"
done
iptables -vxn -t nat -L nat_lan --line-number
iptables -vxn -t nat -L nat_out --line-number
iptables -vxn -t nat -L shadowsocks --line-number