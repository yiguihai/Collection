#!/usr/bin/env bash

status_list=(
redsocks
ss-local
ss-redir
);
for i in ${status_list[@]}
do
  echo "$i $(pgrep $i)"
done
iptables -vxn -t nat -L nat_lan --line-number
iptables -vxn -t nat -L nat_out --line-number
iptables -vxn -t nat -L shadowsocks --line-number