#!/usr/bin/env bash
PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH

now_path="${0%/*}";
if [ ! -d $now_path ]; then
  now_path=$(pwd); 
fi
if [ ! -d $now_path/Download ]; then
  mkdir $now_path/Download; 
fi
if [ ! -f $now_path/aria2.session ]; then
  touch $now_path/aria2.session; 
fi
if [ ! -f $now_path/Cookie ]; then
  touch $now_path/Cookie; 
fi
if [ ! -f $now_path/dht.dat ]; then
  touch $now_path/dht.dat; 
fi
cat > $now_path/aria2c.conf<<-EOF
daemon=true
dir=$now_path/Download
log-level=error
log=$now_path/aria2.log
max-concurrent-downloads=3
input-file=$now_path/aria2.session
save-session=$now_path/aria2.sessionn
dht-file-path=$now_path/dht.dat
save-session-interval=60
enable-rpc=true
rpc-allow-origin-all=true
rpc-listen-all=true
#rpc-secret=ygh15177542493
continue=true
user-agent=MAUI WAP Browser
save-cookies=$now_path/Cookie
load-cookies=$now_path/Cookie
enable-dht=true
async-dns=true
http-accept-gzip=true
bt-tracker=$(wget -qO- https://raw.githubusercontent.com/ngosang/trackerslist/master/trackers_all.txt|awk NF|sed ":a;N;s/\n/,/g;ta")
EOF
$now_path/aria2c --conf-path="$now_path/aria2c.conf" --dir="$now_path/Download" --input-file="$now_path/aria2.session" --save-session="$now_path/aria2.session" --save-cookies="$now_path/Cookie" --load-cookies="$now_path/Cookie" --dht-file-path="$now_path/dht.dat"
