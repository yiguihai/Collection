#!/usr/bin/env bash

status_list=(
redsocks
ss-local
ss-redir
);

for i in ${status_list[@]}
do
  kill $(pgrep $i)
done


iptables -t nat -D OUTPUT -j nat_out

iptables -t nat -F nat_lan
iptables -t nat -F nat_out
iptables -t nat -F shadowsocks
iptables -t nat -X nat_lan
iptables -t nat -X nat_out
iptables -t nat -X shadowsocks