#!/usr/bin/env bash
#wget --no-check-certificate -c -t3 -T60 -O gfwlist.acl https://github.com/shadowsocks/shadowsocks-android/raw/master/core/src/main/assets/acl/gfwlist.acl

now_path="${0%/*}";
acl="gfwlist.acl"

if [ ! -d ${now_path} ]; then
  now_path=$(pwd)
fi

get_ip()(
    local IP=$( ip addr | egrep -o '[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}' | egrep -v "^192\.168|^172\.1[6-9]\.|^172\.2[0-9]\.|^172\.3[0-2]\.|^10\.|^127\.|^255\.|^0\." | head -n 1 )
    [ -z ${IP} ] && IP=$( wget -qO- -t1 -T2 ipv4.icanhazip.com )
    [ -z ${IP} ] && IP=$( wget -qO- -t1 -T2 ipinfo.io/ip )
    echo ${IP}
);

lan_list=(
0.0.0.0/8
10.0.0.0/8
100.64.0.0/10
127.0.0.0/8
169.254.0.0/16
172.16.0.0/12
192.0.0.0/29
192.0.2.0/24
192.88.99.0/24
192.168.0.0/16
198.18.0.0/15
198.51.100.0/24
203.0.113.0/24
224.0.0.0/3
$(get_ip)
);

status_list=(
redsocks
ss-local
ss-redir
);

ss_nat()
(
iptables -t nat -N nat_lan
iptables -t nat -N nat_out
iptables -t nat -N shadowsocks
for i in ${lan_list[@]}
do
  iptables -t nat -A nat_lan -d $i -j ACCEPT
done
iptables -t nat -A nat_out -j nat_lan
iptables -t nat -A nat_out -m owner --gid-owner admin -j ACCEPT
iptables -t nat -A nat_out -m owner --uid-owner $(id -u) -j ACCEPT
iptables -t nat -A nat_out -j shadowsocks
iptables -t nat -A OUTPUT -j nat_out
iptables -t nat -A shadowsocks -p tcp -j REDIRECT --to-ports 1024
#iptables -t nat -A shadowsocks -p udp --dport 53 -j REDIRECT --to-ports 1053
#iptables -t mangle -A mangle_lan -p udp -j LOG --log-prefix "{NL}" --log-uid
#grep '{NL}' /proc/kmsg &
);


if [ $(id -u) -ne 0 ]; then
  echo "请使用ROOT用户执行脚本！"
  exit 1
fi

if [ $(cat /proc/sys/net/ipv4/ip_forward) -le 0 ]; then
  sysctl -w net.ipv4.ip_forward=1 1> /dev/null;
fi

_start(){
if [ ! -f bypass-china.acl ]; then
  touch bypass-china.acl
fi
cat > bypass-china.acl<<-EOF
[proxy_all]

[bypass_list]
$(wget -qO- -t1 http://f.ip.cn/rt/chnroutes.txt|sed 's:^\s*#.*$::g'|tr -s '\n')
EOF
wait
$now_path/redsocks -c $now_path/redsocks.conf
$now_path/ss-local --acl $now_path/$acl -f $now_path/ss-deamon.pid -c $now_path/ss-local.conf
ss_nat
}

_status()(
for i in ${status_list[@]}
do
  echo "$i $(pgrep $i)"
done
iptables -vxn -t nat -L nat_lan --line-number
iptables -vxn -t nat -L nat_out --line-number
iptables -vxn -t nat -L shadowsocks --line-number
)

_stop()(
for i in ${status_list[@]}
do
  kill $(pgrep $i) > /dev/null 2>&1
done

iptables -t nat -D OUTPUT -j nat_out

iptables -t nat -F nat_lan
iptables -t nat -F nat_out
iptables -t nat -F shadowsocks
iptables -t nat -X nat_lan
iptables -t nat -X nat_out
iptables -t nat -X shadowsocks
)

action=$1
case "$action" in
    start)
        _${action}
        ;;
    status)
        _${action}
        ;;
    stop)
        _${action}
        ;;
    *)
        echo "Arguments error! [${action}]"
        echo "Usage: $(basename $0) [start|status|stop]"
        ;;
esac